<?php
/**
 * Plugin Name:       tw_backup_365
 * Plugin URI:        https://example.com/tw-backup-365
 * Description:       Secure Full Site Backup with Splitting, Anti-DoS, and Randomized Filenames.
 * Version:           1.2.0 (Security Hardened)
 * Author:            Your Name
 * Text Domain:       tw-backup-365
 * Domain Path:       /languages
 * Requires at least: 5.0
 * Requires PHP:      7.4
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Tw_Backup_365 {

	// 設定每個分片的大小 (Bytes)，預設 20MB
	private $chunk_size = 20 * 1024 * 1024; 
	
	// 備份冷卻時間 (秒)，防止 DoS 攻擊
	private $cooldown_time = 600; // 10 分鐘

	private $backup_dir;
	private $backup_url;

	public function __construct() {
		$upload_dir = wp_upload_dir();
		// 使用亂數名稱的資料夾增加一層隱密性 (可選，這裡維持固定名稱但增強內容防護)
		$this->backup_dir = $upload_dir['basedir'] . '/tw-backup-secure';
		$this->backup_url = $upload_dir['baseurl'] . '/tw-backup-secure';

		add_action( 'plugins_loaded', array( $this, 'load_textdomain' ) );
		add_action( 'admin_menu', array( $this, 'add_admin_menu' ) );
		add_action( 'admin_post_tw_backup_trigger', array( $this, 'handle_backup_process' ) );
	}

	public function load_textdomain() {
		load_plugin_textdomain( 'tw-backup-365', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' );
	}

	public function add_admin_menu() {
		add_menu_page(
			__( 'Backup 365', 'tw-backup-365' ),
			__( 'Backup 365', 'tw-backup-365' ),
			'manage_options',
			'tw-backup-365',
			array( $this, 'render_admin_page' ),
			'dashicons-shield-alt'
		);
	}

	public function render_admin_page() {
		// 檢查並建立安全目錄
		$this->check_secure_dir();
		
		// 掃描現有的備份檔案
		$existing_files = glob( $this->backup_dir . '/*' );
		
		// 檢查是否在冷卻時間內
		$is_cooldown = get_transient( 'tw_backup_cooldown' );
		?>
		<div class="wrap">
			<h1><?php esc_html_e( 'TW Backup 365 - Security Hardened', 'tw-backup-365' ); ?></h1>
			
			<div class="card" style="max-width: 700px;">
				<h2><?php esc_html_e( 'One-Click Secure Backup', 'tw-backup-365' ); ?></h2>
				<p>
					<?php esc_html_e( 'Backups are split into 20MB parts. Filenames are randomized to prevent unauthorized guessing.', 'tw-backup-365' ); ?>
				</p>
				
				<div class="notice notice-warning inline" style="margin: 10px 0; padding: 10px;">
					<p><strong><?php esc_html_e( 'Security Note:', 'tw-backup-365' ); ?></strong> 
					<?php esc_html_e( 'If you use Nginx, please ensure directory listing is disabled. We have added randomized filenames as a secondary defense.', 'tw-backup-365' ); ?></p>
				</div>

				<p class="description">
					<?php 
					// 防禦 A05: 避免顯示絕對路徑，只顯示相對路徑
					printf( esc_html__( 'Storage: %s', 'tw-backup-365' ), '<code>.../wp-content/uploads/tw-backup-secure/</code>' ); 
					?>
				</p>
				
				<form action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" method="post">
					<?php wp_nonce_field( 'tw_backup_action', 'tw_backup_nonce' ); ?>
					<input type="hidden" name="action" value="tw_backup_trigger">
					
					<?php if ( $is_cooldown ) : ?>
						<button type="button" class="button button-secondary" disabled>
							<?php printf( esc_html__( 'Please wait %d minutes before next backup', 'tw-backup-365' ), ceil( ( $is_cooldown - time() ) / 60 ) ); ?>
						</button>
					<?php else : ?>
						<?php submit_button( __( 'Start Secure Backup', 'tw-backup-365' ), 'primary' ); ?>
					<?php endif; ?>
				</form>
			</div>

			<div class="card" style="margin-top:20px; max-width: 700px;">
				<h3><?php esc_html_e( 'Backup History', 'tw-backup-365' ); ?></h3>
				<?php if ( empty( $existing_files ) ) : ?>
					<p><?php esc_html_e( 'No backups found.', 'tw-backup-365' ); ?></p>
				<?php else : ?>
					<ul style="list-style-type: disc; padding-left: 20px;">
						<?php foreach ( $existing_files as $file ) : 
							$basename = basename( $file );
							// 隱藏系統檔案與目錄
							if ( is_dir( $file ) || in_array( $basename, ['.htaccess', 'web.config', 'index.php', 'index.html'] ) ) continue;
						?>
							<li style="margin-bottom: 5px;">
								<code><?php echo esc_html( $basename ); ?></code> 
								<span style="color:#666;">(<?php echo size_format( filesize( $file ) ); ?>)</span>
							</li>
						<?php endforeach; ?>
					</ul>
					<p class="description">
						<strong><?php esc_html_e( 'How to Restore:', 'tw-backup-365' ); ?></strong><br>
						<?php esc_html_e( 'Download all parts (.001, .002...) via FTP/SFTP. Use 7-Zip (Windows) or Keka (Mac) to extract the first file.', 'tw-backup-365' ); ?>
					</p>
				<?php endif; ?>
			</div>
			
			<?php if ( isset( $_GET['status'] ) ) : ?>
				<div class="notice notice-<?php echo esc_attr( $_GET['status'] === 'success' ? 'success' : 'error' ); ?> is-dismissible">
					<p>
						<?php 
						if ( $_GET['status'] === 'success' ) {
							esc_html_e( 'Backup completed successfully!', 'tw-backup-365' );
						} elseif ( $_GET['status'] === 'ratelimit' ) {
							esc_html_e( 'Backup failed: Too many requests. Please wait.', 'tw-backup-365' );
						} else {
							esc_html_e( 'Backup failed. Check error logs.', 'tw-backup-365' );
						}
						?>
					</p>
				</div>
			<?php endif; ?>
		</div>
		<?php
	}

	/**
	 * 建立多重安全防護目錄
	 * 防禦 A01: Broken Access Control
	 */
	private function check_secure_dir() {
		if ( ! file_exists( $this->backup_dir ) ) {
			wp_mkdir_p( $this->backup_dir );
		}

		// 1. Apache / LiteSpeed 防護
		$htaccess_file = $this->backup_dir . '/.htaccess';
		if ( ! file_exists( $htaccess_file ) ) {
			file_put_contents( $htaccess_file, "Order Deny,Allow\nDeny from all" );
		}

		// 2. IIS 防護 (web.config)
		$web_config_file = $this->backup_dir . '/web.config';
		if ( ! file_exists( $web_config_file ) ) {
			$xml = '<?xml version="1.0" encoding="UTF-8"?>
			<configuration>
			  <system.webServer>
				<authorization>
				  <deny users="*" />
				</authorization>
			  </system.webServer>
			</configuration>';
			file_put_contents( $web_config_file, $xml );
		}

		// 3. 一般目錄列表防護 (Directory Listing)
		$index_php = $this->backup_dir . '/index.php';
		$index_html = $this->backup_dir . '/index.html';
		if ( ! file_exists( $index_php ) ) file_put_contents( $index_php, '<?php // Silence is golden.' );
		if ( ! file_exists( $index_html ) ) file_put_contents( $index_html, '' );
	}

	public function handle_backup_process() {
		// 1. 基礎權限檢查
		if ( ! isset( $_POST['tw_backup_nonce'] ) || ! wp_verify_nonce( $_POST['tw_backup_nonce'], 'tw_backup_action' ) ) {
			wp_die( __( 'Security check failed.', 'tw-backup-365' ) );
		}
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( __( 'Permission denied.', 'tw-backup-365' ) );
		}

		// 2. 防禦 A04: DoS 攻擊防護 (Rate Limiting)
		if ( get_transient( 'tw_backup_cooldown' ) ) {
			$this->redirect_status( 'ratelimit' );
		}

		// 設定無限制執行時間
		set_time_limit( 0 );
		ini_set( 'memory_limit', '512M' );

		// 3. 設定冷卻時間標記
		set_transient( 'tw_backup_cooldown', time() + $this->cooldown_time, $this->cooldown_time );

		// 4. 防禦 A01: 生成不可預測的亂數檔名
		// 使用 16 byte 隨機亂數 (32 char hex)
		try {
			$random_hash = bin2hex( random_bytes( 16 ) );
		} catch ( Exception $e ) {
			$random_hash = wp_generate_password( 32, false );
		}
		
		$site_name = sanitize_file_name( get_bloginfo( 'name' ) );
		$date_str = date( 'YmdHis' );
		
		// 檔名格式：SiteName_Date_RANDOMHASH_FULL.zip
		$temp_zip_name = $site_name . '_' . $date_str . '_' . $random_hash . '_FULL.zip';
		$temp_zip_path = $this->backup_dir . '/' . $temp_zip_name;

		// 匯出 SQL
		$sql_file = 'db_backup.sql';
		$sql_path = sys_get_temp_dir() . '/' . $sql_file;
		if ( ! $this->dump_database( $sql_path ) ) {
			$this->redirect_status( 'error' );
		}

		// 壓縮與分片
		if ( $this->zip_website_optimized( $temp_zip_path, $sql_path, $sql_file ) ) {
			@unlink( $sql_path ); // 刪除 SQL 暫存

			if ( $this->split_file( $temp_zip_path ) ) {
				$this->redirect_status( 'success' );
			} else {
				$this->redirect_status( 'error' );
			}
		} else {
			$this->redirect_status( 'error' );
		}
	}

	private function redirect_status( $status ) {
		wp_redirect( admin_url( 'admin.php?page=tw-backup-365&status=' . $status ) );
		exit;
	}

	// ... [資料庫匯出 dump_database 函數保持不變] ...
	private function dump_database( $output_file ) {
		global $wpdb;
		$tables = $wpdb->get_results( 'SHOW TABLES', ARRAY_N );
		$handle = fopen( $output_file, 'w' );
		if ( ! $handle ) return false;

		fwrite( $handle, "-- WordPress Database Backup\n\n" );
		foreach ( $tables as $table ) {
			$table_name = $table[0];
			$create_table = $wpdb->get_row( "SHOW CREATE TABLE `$table_name`", ARRAY_N );
			fwrite( $handle, "\n" . $create_table[1] . ";\n\n" );
			
			$rows = $wpdb->get_results( "SELECT * FROM `$table_name`", ARRAY_A );
			if ( $rows ) {
				foreach ( $rows as $row ) {
					$row = array_map( array( $wpdb, '_real_escape' ), $row );
					$sql = "INSERT INTO `$table_name` VALUES ('" . implode( "', '", $row ) . "');\n";
					fwrite( $handle, $sql );
				}
			}
		}
		fclose( $handle );
		return true;
	}

	// ... [zip_website_optimized 函數保持不變] ...
	private function zip_website_optimized( $zip_destination, $sql_path, $sql_filename_in_zip ) {
		if ( ! class_exists( 'ZipArchive' ) ) return false;

		$zip = new ZipArchive();
		if ( $zip->open( $zip_destination, ZipArchive::CREATE | ZipArchive::OVERWRITE ) !== true ) {
			return false;
		}

		$zip->addFile( $sql_path, $sql_filename_in_zip );

		$root_path = realpath( ABSPATH );
		$files = new RecursiveIteratorIterator(
			new RecursiveDirectoryIterator( $root_path, RecursiveDirectoryIterator::SKIP_DOTS ),
			RecursiveIteratorIterator::LEAVES_ONLY
		);

		$file_count = 0;
		$flush_threshold = 500; 

		foreach ( $files as $name => $file ) {
			// 重要：排除備份目錄，防止無限遞迴
			if ( strpos( $file->getRealPath(), 'tw-backup-secure' ) !== false ) continue;
			if ( $file->getExtension() === 'zip' || $file->getExtension() === 'gz' ) continue; 

			$filePath = $file->getRealPath();
			$relativePath = substr( $filePath, strlen( $root_path ) + 1 );

			if ( ! $file->isDir() ) {
				$zip->addFile( $filePath, $relativePath );
				$file_count++;
			}

			if ( $file_count >= $flush_threshold ) {
				$zip->close(); 
				$zip->open( $zip_destination ); 
				$file_count = 0;
			}
		}

		$zip->close();
		return true;
	}

	// ... [split_file 函數保持不變] ...
	private function split_file( $source_file ) {
		if ( ! file_exists( $source_file ) ) return false;

		$handle = fopen( $source_file, 'rb' );
		if ( ! $handle ) return false;

		$part_num = 1;
		$buffer_size = 1024 * 1024; 

		while ( ! feof( $handle ) ) {
			$part_filename = $source_file . '.' . sprintf( '%03d', $part_num );
			$part_handle = fopen( $part_filename, 'wb' );
			
			$written = 0;
			while ( $written < $this->chunk_size && ! feof( $handle ) ) {
				$data = fread( $handle, $buffer_size );
				if ( $data === false ) break;
				fwrite( $part_handle, $data );
				$written += strlen( $data );
			}
			
			fclose( $part_handle );
			$part_num++;
		}

		fclose( $handle );
		unlink( $source_file );
		
		return true;
	}
}

new Tw_Backup_365();